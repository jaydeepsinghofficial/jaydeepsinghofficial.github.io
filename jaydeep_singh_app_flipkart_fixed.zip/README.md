# Jaydeep Singh — App bundle

## Files
- `index.html` — application UI and existing features
- `profile.jpg` — profile image supplied by Jaydeep
- `book-cover.jpg` — Echoes of Destiny cover supplied by Jaydeep
- `manifest.json`, `service-worker.js`, `assets/icon-192.png`, `assets/icon-512.png` — PWA setup
- `data/syllabus-data.js`, `data/question-bank.js` — learning data currently connected to the UI

## Publish
Upload the contents of this folder to the root of the GitHub Pages repository, keeping the `data/` and `assets/` folders and existing Supabase project configuration in `index.html`. Do not upload only `index.html`, because it imports both learning-data scripts.

## Flipkart link
Open `index.html` and find `const CONFIG={flipkart:""};`. Paste the genuine live listing URL inside the quotes, e.g. `const CONFIG={flipkart:"https://..."};`. The visible button says **Buy on Flipkart** and activates only when a valid HTTPS URL is entered.

## Install and zoom
The page uses a mobile viewport that disables pinch zoom in supported browsers. Install is shown in the menu when the browser offers the PWA install prompt; the contact section also keeps an install/status control. Browser support and install availability vary. If the prompt is not available, Chrome's menu can offer **Add to Home screen**.

## Important content status
This is a packaged working base, not a claim that every course is fully authored. The connected data currently contains chapter indexes and starter practice sets. It does **not** yet contain complete official updated syllabus coverage, full 3-hour Class 10/11/12 mock libraries (10 per subject), complete JEE Main + Advanced/NEET papers, or complete SSC/Railway/Bank/Defence mock sets matching each exam's exact question count and latest pattern. The supplied questions are practice material, not verified official previous-year questions. Please do not advertise those libraries as complete until the content is written and checked subject-by-subject against the current official notifications and syllabi.

## Checks performed
JavaScript syntax checks passed for the inline app script, syllabus data, question bank and service worker. This is not the same as end-to-end testing on a live phone, real login, or every exam workflow.


## Install and Flipkart controls (updated)
- Install app is visible in the three-line menu and in the Contact area. The browser install prompt appears when supported; otherwise the button explains Chrome menu installation. Installed state is shown green when the app is running as an installed PWA or the browser fires `appinstalled`.
- Featured book has a `Buy on Flipkart` button. To activate it, paste the genuine listing URL into `const CONFIG={flipkart:""};` in `index.html`. No fake listing URL is supplied.
- `profile.jpg` and `book-cover.jpg` are the images supplied for this build.
